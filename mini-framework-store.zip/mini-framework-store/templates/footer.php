    <footer class="bg-light text-center text-lg-start">
        <div class="text-center p-3">
            Copyright © 2025 Online Store. All rights reserved.
        </div>
    </footer>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>