# How to install
1. Clone the repo to your local
2. Run composer install
3. Serve the code via Xampp by pasting the code to the xampp htdocs folder
4. PLEASE NOTE that the database is NOT provided.
